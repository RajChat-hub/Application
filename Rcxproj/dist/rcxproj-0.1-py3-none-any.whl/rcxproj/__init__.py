# __init__.py
"""
rcxproj: A custom build system by Rajdeep Chatterjee
"""